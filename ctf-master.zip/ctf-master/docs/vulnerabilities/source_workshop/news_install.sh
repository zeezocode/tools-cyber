#!/bin/bash
mkdir "./users"
mkdir "./articles"
echo "adding a default example article as example.txt"
echo "This is an example article" > ./articles/example.txt
echo "adding a default user as guest"
echo "guest" > ./users/guest.txt
