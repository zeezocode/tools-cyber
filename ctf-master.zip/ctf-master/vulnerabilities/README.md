# Vulnerability Discovery

<script async class="speakerdeck-embed" data-id="da345c70b92c0131e4474251e58a135f" data-ratio="1.33333333333333" src="//speakerdeck.com/assets/embed.js"></script>
